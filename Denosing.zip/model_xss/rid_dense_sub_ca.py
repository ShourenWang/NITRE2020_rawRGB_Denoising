import math
import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F

class BasicBlock(nn.Module):
    def __init__(self,
                 in_channels, out_channels,
                 ksize=3, stride=1):
        super(BasicBlock, self).__init__()

        self.body = nn.Sequential(
            nn.ReflectionPad2d(ksize//2),
            nn.Conv2d(in_channels, out_channels, ksize, stride, 0),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        out = self.body(x)
        return out


class BasicBlockSig(nn.Module):
    def __init__(self,
                 in_channels, out_channels,
                 ksize=3, stride=1):
        super(BasicBlockSig, self).__init__()

        self.body = nn.Sequential(
            nn.ReflectionPad2d(ksize//2),
            nn.Conv2d(in_channels, out_channels, ksize, stride, 0),
            nn.Sigmoid()
        )

    def forward(self, x):
        out = self.body(x)
        return out


class CALayer(nn.Module):  # attention channel
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()

        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        self.c1 = BasicBlock(channel , channel // reduction, 1, 1)
        self.c2 = BasicBlockSig(channel // reduction, channel , 1, 1)

    def forward(self, x):
        y = self.avg_pool(x)
        y1 = self.c1(y)
        y2 = self.c2(y1)
        return x * y2



class MeanShift(nn.Conv2d):
    def __init__(self, rgb_range, rgb_mean, rgb_std, sign=-1):
        super(MeanShift, self).__init__(4, 4, kernel_size=1)
        std = torch.Tensor(rgb_std)
        self.weight.data = torch.eye(4).view(4, 4, 1, 1)
        self.weight.data.div_(std.view(4, 1, 1, 1))
        self.bias.data = sign * rgb_range * torch.Tensor(rgb_mean)
        self.bias.data.div_(std)
        self.requires_grad = False


class Merge_Run_dilate(nn.Module):
    def __init__(self,
                 in_channels, out_channels,
                 ksize=3, stride=1):
        super(Merge_Run_dilate, self).__init__()

        self.body1 = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(in_channels, out_channels, ksize, stride, 0),
            nn.ReLU(inplace=True),
            nn.ReflectionPad2d(2),
            nn.Conv2d(in_channels, out_channels, ksize, stride, 0, 2),
            nn.ReLU(inplace=True)
        )
        self.body2 = nn.Sequential(
            nn.ReflectionPad2d(3),
            nn.Conv2d(in_channels, out_channels, ksize, stride, 0, 3),
            nn.ReLU(inplace=True),
            nn.ReflectionPad2d(4),
            nn.Conv2d(in_channels, out_channels, ksize, stride, 0, 4),
            nn.ReLU(inplace=True)
        )

        self.body3 = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(in_channels * 2, out_channels, ksize, stride, 0),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        out1 = self.body1(x)
        out2 = self.body2(x)
        c = torch.cat([out1, out2], dim=1)
        c_out = self.body3(c)
        out = c_out + x
        return out


class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels,kernelsize=3):
        super(ResidualBlock, self).__init__()

        self.body = nn.Sequential(
            nn.Conv2d(in_channels, out_channels*2, 1, 1, 0),
            nn.ReLU(inplace=True),
            nn.ReflectionPad2d(kernelsize//2),
            nn.Conv2d(out_channels*2, out_channels*2, kernelsize, 1, 0, groups=out_channels*2),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels*2, out_channels, 1, 1, 0),
        )


    def forward(self, x):
        out = self.body(x)
        out = F.relu(out + x)
        return out


class rid_model(nn.Module):
    def __init__(self, in_channels = 4, channels_basenum = 64):
        super(rid_model, self).__init__()
        self.head = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(in_channels, channels_basenum, 3, 1, 0),
            nn.ReLU(inplace=True),
        )
        self.basic_block = Merge_Run_dilate(channels_basenum, channels_basenum,ksize=3, stride=1)
        self.trans3 = ResidualBlock(channels_basenum, channels_basenum, kernelsize=3)
        self.trans5 = ResidualBlock(channels_basenum, channels_basenum, kernelsize=5)

        self.tail = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(channels_basenum, in_channels, 3, 1, 0),
        )

        rgb_mean = (0.4488, 0.4371,0.4371,  0.4040)
        rgb_std = (1.0, 1.0, 1.0,1.0)

        self.sub_mean = MeanShift(1, rgb_mean, rgb_std)
        self.add_mean = MeanShift(1, rgb_mean, rgb_std, 1)

        self.ca = CALayer(channels_basenum)


    def forward(self, x):
        ori = self.sub_mean(x)

        x1 = self.head(ori)
        x2 = self.basic_block(x1)
        x2 = self.trans3(x1 + x2)
        x2 = self.ca(x2)

        x3 = self.basic_block(x2)
        x3 = self.trans5(x1 + x2 + x3)
        x3 = self.ca(x3)

        x4 = self.basic_block(x3)
        x4 = self.trans3(x1 + x2 + x3 + x4)
        x4 = self.ca(x4)

        x5 = self.basic_block(x4)
        x5 = self.trans5(x1 + x2 + x3 + x4 + x5)
        x5 = self.ca(x5)

        x6 = self.basic_block(x5)
        x6 = self.trans3(x1 + x2 + x3 + x4 + x5 + x6)
        x6 = self.ca(x6)

        x7 = self.basic_block(x6)
        x7 = self.trans5(x1 + x2 + x3 + x4 + x5 + x6 + x7)

        out = self.tail(x7)

        out = self.add_mean(out)
        out = out + ori

        return out



