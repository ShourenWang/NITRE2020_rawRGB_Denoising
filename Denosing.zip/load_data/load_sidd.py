# encoding:utf-8
import torch.utils.data as data
import torch
from torchvision import transforms
import glob

import h5py
import numpy as np

class MyTrainData(data.Dataset):
    def __init__(self, root,patch_size,debug_=False):  # 第一步初始化各个变量

        self.root = root
        self.subpath = [tmp for tmp in glob.glob(self.root + '0*')]
        self.bayerdict = {}
        self.bayerdict['GP'] = 'BGGR'
        self.bayerdict['IP'] = 'RGGB'
        self.bayerdict['S6'] = 'GRBG'
        self.bayerdict['N6'] = 'BGGR'
        self.bayerdict['G4'] = 'BGGR'
        self.patch_size = patch_size
        self.debug_ = debug_
        if self.debug_:
            self.subpath = self.subpath[1:10]


    def __getitem__(self, idx):
        cleanraw_ = h5py.File(self.subpath[idx] + '/' + 'GT_RAW_010.MAT','r')['x'][:]
        noisyraw_ = h5py.File(self.subpath[idx] + '/' + 'NOISY_RAW_010.MAT','r')['x'][:]

        w,h = noisyraw_.shape[:2]
        camera_id = self.subpath[idx].split('/')[-1].split('_')[2]
        pattern = self.bayerdict[camera_id]

        patch_w = np.random.randint(0, w - self.patch_size -1)
        patch_h = np.random.randint(0, h - self.patch_size -1)

        if pattern == 'BGGR' or pattern == 'RGGB':
            patch_w = int(patch_w / 2) * 2
            patch_h = int(patch_h / 2) * 2
        elif pattern == 'GRBG':
            patch_w = int(patch_w / 2) * 2
            patch_h = int(patch_h / 2) * 2 + 1

        clean_patch = cleanraw_[patch_w:patch_w+self.patch_size, patch_h:patch_h+self.patch_size]
        noisy_patch = noisyraw_[patch_w:patch_w+self.patch_size, patch_h:patch_h+self.patch_size]

        noi = np.zeros((int(self.patch_size / 2), int(self.patch_size / 2),4),dtype = 'float32')
        gt = np.zeros((int(self.patch_size / 2), int(self.patch_size / 2), 4), dtype='float32')

        noi[:, :, 0] = noisy_patch[0::2, 0::2]
        noi[:, :, 1] = noisy_patch[1::2, 0::2]
        noi[:, :, 2] = noisy_patch[0::2, 1::2]
        noi[:, :, 3] = noisy_patch[1::2, 1::2]

        gt[:, :, 0] = clean_patch[0::2, 0::2]
        gt[:, :, 1] = clean_patch[1::2, 0::2]
        gt[:, :, 2] = clean_patch[0::2, 1::2]
        gt[:, :, 3] = clean_patch[1::2, 1::2]

        flagt = np.random.randint(0, 9)
        if flagt == 0:
            noi = np.rot90(noi,-1)
            gt = np.rot90(gt, -1)
        if flagt == 1:
            noi = np.rot90(noi,2)
            gt = np.rot90(gt, 2)
        if flagt == 2:
            noi = np.rot90(noi,3)
            gt = np.rot90(gt, 3)
        if flagt > 6:
            sigma = np.random.randint(20)
            noi = noi + np.random.randn(int(self.patch_size / 2), int(self.patch_size / 2),4) * sigma / 255

        noi = np.clip(noi,0,1)
        gt = np.clip(gt, 0, 1)

        gt = gt.transpose(2, 0, 1)
        noi = noi.transpose(2, 0, 1)
        gt = torch.from_numpy(gt).float()
        noi = torch.from_numpy(noi).float()

        return noi, gt

    def __len__(self):
        return len(self.subpath)  # 这个是必须返回的长度

